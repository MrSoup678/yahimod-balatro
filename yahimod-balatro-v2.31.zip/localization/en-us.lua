-- idk why this wouldn't work unless if i put it in a separate localization file. ill be damned
return {
    descriptions = {
        Other = {
            yahimod_artcredit = {
                            name = "Art by",
                            text = {
                                "{C:attention}#1#{}"
                            },
                        },
            yahimod_ideacredit = {
                            name = "Idea by",
                            text = {
                                "{C:blue}#1#{}"
                            },
                        },
            yahimod_catcredit = {
                            name = "Cat",
                            text = {
                                "{C:green}#1#{}'s cat!"
                            },
                        },
                        
            },
           
    },
    misc = {
            poker_hands = {
                test_jerma = "jerma loc txt",
            },
        },
    Stake = {
            yahimod_stake_camel = {
                name = "Camel Stake",
                text = {
                    'Cards can have a',
                    'Made in Morocco sticker'
                },
            },
        },
    Sticker = {
            yahimod_sticker_madeinmorocco = {
                name = "Made In Morocco",
                text = {
                    'Card costs $2 but will',
                    'self-destruct 2 turns after',
                    'being bought'
                },
            },
        },
}