# YAHIMOD: the Stupidest Balatro Mod on Earth
The YAHIMOD's a (somewhat unbalanced) mess of custom jokers, tarots and blinds, loosely themed around [Yahiamice](https://www.youtube.com/@YahiamiceLIVE) (yes, i'm self-centered) with several meta effects that stray from the base game; like throwing a wet trout at your screen or forcing the game speed to be 0.25x

![A display of the dumb jokers contained in this mod](https://i.imgur.com/G9Hvo78.png)

# Installing Instructions
1) Install the [Lovely injector](https://github.com/ethangreen-dev/lovely-injector): https://github.com/ethangreen-dev/lovely-injector
2) Download [Steamodded](https://github.com/Steamodded/smods) and add it to your %AppData%Roaming\Balatro\mods folder https://github.com/Steamodded/smods
3) Download the [latest release](https://github.com/Yahiamice/yahimod-balatro/releases) of the Yahimod and extract the folder into %AppData%Roaming\Balatro\mods
   It should look like this
   ![\AppData\Roaming\Balatro\mods](https://i.imgur.com/WaVn9Jd.png)
4) Launch the game and click the Mods button, it should've loaded properly if you followed the steps correctly!

 ![Ingame look at it](https://i.imgur.com/cJKqefE.png)

 # DISCLAIMER
   I didn't build this mod with cross-mod compatibility in mind. Please don't report issues pertaining to crashes related to other mods, thank you.
